---
title: "News"
showDate: false
---
<!-- <link rel="stylesheet" type="text/css"
    href="https://cdn.jsdelivr.net/gh/sampsyo/emfed@1/toots.css"> -->

<!-- <link rel="stylesheet" type="text/css"
    href="/masto.css"> -->

<a class="mastodon-feed" href="https://mstdn.social/@W_Lucht"
   data-toot-limit="4">follow me into the Fediverse</a>


<script type="module" src="https://esm.sh/emfed"></script>




<!-- [RSS](https://mstdn.social/@StefanAykut.rss)

### Feed
<iframe allowfullscreen sandbox="allow-top-navigation allow-scripts" width="600" height="400" src="http://www.mastofeed.com/apiv2/feed?userurl=https%3A%2F%2Fmstdn.social%2Fusers%2FStefanAykut&theme=auto&size=80&header=false&replies=true&boosts=false"></iframe>

### Slow news

- Dec 12, 22: rock  -->
